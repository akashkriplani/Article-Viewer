export class Article {
  public userId?: number;
  public id?: number;
  public title?: string;
  public body?: string;

  constructor(){
    
  }
}